﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace AvaloniaDrivers.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}