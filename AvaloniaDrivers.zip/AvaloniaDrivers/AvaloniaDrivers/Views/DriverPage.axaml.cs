using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace AvaloniaDrivers.Views;

public partial class DriverPage : UserControl
{
    public DriverPage()
    {
        InitializeComponent();
    }

    void LoadData()
    {
        
    }
}