using Avalonia.Controls;
using Avalonia.Interactivity;
using AvaloniaDrivers.Classes;

namespace AvaloniaDrivers.Views;

public partial class AuthPage : UserControl
{
    public AuthPage()
    {
        InitializeComponent();
    }

    private void AuthBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LoginTb.Text == "inspector" && PasswordTb.Text == "inspector")
        {
            Help.MainCC.Content = new DriverPage();
        }
    }
}