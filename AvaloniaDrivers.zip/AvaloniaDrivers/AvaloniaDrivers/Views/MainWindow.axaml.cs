using Avalonia.Controls;
using Avalonia.Interactivity;
using AvaloniaDrivers.Classes;

namespace AvaloniaDrivers.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.MainCC = MainCC;
        MainCC.Content = new AuthPage();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Close();
    }
}