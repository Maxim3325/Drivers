using Avalonia.Controls;

namespace AvaloniaDrivers.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}