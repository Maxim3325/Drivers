using Avalonia.Controls;

namespace AvaloniaDrivers.Classes;

public static class Help
{
    public static ContentControl MainCC;
}