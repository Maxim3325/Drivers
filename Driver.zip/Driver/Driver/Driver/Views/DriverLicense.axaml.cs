using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Driver.Classes;
using Microsoft.EntityFrameworkCore;

namespace Driver.Views;

public partial class DriverLicense : UserControl
{
    public DriverLicense()
    {
        InitializeComponent();
        LoadData();
    }

    void LoadData()
    {
        Help.Db.Photos.Load();
        Help.Db.Statuses.Load();
        Help.Db.DriversLicens.Load();
        DriverLicenseDg.ItemsSource = Help.Db.DriversLicens.ToList();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new CardPage();
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new EditLicense();
    }
}