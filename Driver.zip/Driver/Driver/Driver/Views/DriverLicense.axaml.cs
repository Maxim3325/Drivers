using System.ComponentModel;
using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Driver.Classes;
using Driver.Models;
using Microsoft.EntityFrameworkCore;

namespace Driver.Views;

public partial class DriverLicense : UserControl
{
    public DriverLicense()
    {
        InitializeComponent();
        LoadData();
    }

    void LoadData()
    {
        Help.Db.Photos.Load();
        Help.Db.Statuses.Load();
        Help.Db.DriversLicens.Load();
        DriverLicenseDg.ItemsSource = Help.Db.DriversLicens.ToList();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        var selected = DriverLicenseDg.SelectedItem as DriversLicen;

        if (selected != null)
        {
            Help.MainCC.Content = new CardPage(selected.Id);
        }
        
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new EditLicense();
    }
}