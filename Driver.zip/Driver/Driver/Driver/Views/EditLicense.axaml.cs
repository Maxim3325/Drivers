using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Driver.Classes;
using Driver.Models;

namespace Driver.Views;

public partial class EditLicense : UserControl
{
    public EditLicense()
    {
        InitializeComponent();
    }

    private void OkBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.Db.DriversLicens.Add(LicenseSp.DataContext as DriversLicen);
        Help.Db.SaveChanges();
        Help.MainCC.Content = new MainView();
    }
    
    

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new DriverLicense();
    }
}