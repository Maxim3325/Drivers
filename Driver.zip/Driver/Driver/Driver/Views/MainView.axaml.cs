using Avalonia.Controls;

namespace Driver.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}