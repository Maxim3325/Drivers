using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Driver.Classes;

namespace Driver.Views;

public partial class AuthPage : UserControl
{
    public AuthPage()
    {
        InitializeComponent();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        if (LoginTb.Text == "inspector" && PasswordTb.Text == "inspector")
        {
            Help.MainCC.Content = new DriverLicense();
        }
    }
}