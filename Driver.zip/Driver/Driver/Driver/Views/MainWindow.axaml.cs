using Avalonia.Controls;
using Avalonia.Interactivity;
using Driver.Classes;

namespace Driver.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.MainCC = MainCC;
        Help.MainCC.Content = new AuthPage();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Close();
    }
}