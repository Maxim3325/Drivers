using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Driver.Classes;

namespace Driver.Views;

public partial class CardPage : UserControl
{
    public CardPage()
    {
        InitializeComponent();
        LoadData();
    }

    void LoadData()
    {
        
    }

    private void BackBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new DriverLicense();
    }
}