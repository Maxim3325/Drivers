using System.Net;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Avalonia.Media.Imaging;
using Driver.Classes;

namespace Driver.Views;

public partial class CardPage : UserControl
{
    public CardPage(int id = -1)
    {
        InitializeComponent();
        LoadData();
    }

    void LoadData()
    {
        
        //Photo.Source = new Bitmap();
    }

    private void BackBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new DriverLicense();
    }
}