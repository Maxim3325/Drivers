using Avalonia.Controls;
using Driver.Models;

namespace Driver.Classes;

public static class Help
{
    public static ContentControl MainCC;
    public static DriverContext Db = new DriverContext();
}