﻿using System;
using System.Collections.Generic;

namespace Driver.Models;

public partial class DriversLicen
{
    public int Id { get; set; }

    public string LicenceDate { get; set; } = null!;

    public string ExpireDate { get; set; } = null!;

    public string? Categories { get; set; }

    public string LicenceSeries { get; set; } = null!;

    public int LicenceNumber { get; set; }

    public int StatusId { get; set; }

    public int? PhotoId { get; set; }

    public virtual Photo? Photo { get; set; }

    public virtual Status Status { get; set; } = null!;
}
