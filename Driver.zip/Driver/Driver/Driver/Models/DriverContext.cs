﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace Driver.Models;

public partial class DriverContext : DbContext
{
    public DriverContext()
    {
    }

    public DriverContext(DbContextOptions<DriverContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Driver> Drivers { get; set; }

    public virtual DbSet<DriversLicen> DriversLicens { get; set; }

    public virtual DbSet<Photo> Photos { get; set; }

    public virtual DbSet<Status> Statuses { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=127.0.0.1;database=Driver;uid=root;pwd=12345", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.5.23-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Driver>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("Driver");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.Address)
                .HasMaxLength(45)
                .HasColumnName("address");
            entity.Property(e => e.Middlename)
                .HasMaxLength(45)
                .HasColumnName("middlename");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
        });

        modelBuilder.Entity<DriversLicen>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.HasIndex(e => e.StatusId, "StatusId_idx");

            entity.HasIndex(e => e.PhotoId, "photoId_idx");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.Categories)
                .HasMaxLength(45)
                .HasColumnName("categories");
            entity.Property(e => e.ExpireDate)
                .HasMaxLength(45)
                .HasColumnName("expire date");
            entity.Property(e => e.LicenceDate)
                .HasMaxLength(45)
                .HasColumnName("licence date");
            entity.Property(e => e.LicenceNumber)
                .HasColumnType("int(11)")
                .HasColumnName("licence number");
            entity.Property(e => e.LicenceSeries)
                .HasMaxLength(45)
                .HasColumnName("licence series");
            entity.Property(e => e.PhotoId)
                .HasColumnType("int(11)")
                .HasColumnName("photoId");
            entity.Property(e => e.StatusId).HasColumnType("int(11)");

            entity.HasOne(d => d.Photo).WithMany(p => p.DriversLicens)
                .HasForeignKey(d => d.PhotoId)
                .HasConstraintName("PhotoId");

            entity.HasOne(d => d.Status).WithMany(p => p.DriversLicens)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("StatusId");
        });

        modelBuilder.Entity<Photo>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("Photo");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.PhotoBlob)
                .HasColumnType("blob")
                .HasColumnName("photo BLOB");
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("Status");

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
