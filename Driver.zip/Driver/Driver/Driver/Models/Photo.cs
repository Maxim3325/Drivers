﻿using System;
using System.Collections.Generic;

namespace Driver.Models;

public partial class Photo
{
    public int Id { get; set; }

    public byte[] PhotoBlob { get; set; } = null!;

    public virtual ICollection<DriversLicen> DriversLicens { get; set; } = new List<DriversLicen>();
}
