﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Driver.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}