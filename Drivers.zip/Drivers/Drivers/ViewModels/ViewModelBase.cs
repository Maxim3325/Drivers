﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Drivers.ViewModels;

public class ViewModelBase : ObservableObject
{
}
