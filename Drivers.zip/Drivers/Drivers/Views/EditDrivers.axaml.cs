using System;
using System.IO;
using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using Drivers.Classes;
using Drivers.Data;

namespace Drivers.Views;

public partial class EditDrivers : UserControl
{
    int _id = -1;
    public EditDrivers(int id = -1)
    {
        InitializeComponent();
        _id = id;
        if (_id == -1)
        {
            MainSp.DataContext = new Driver() { Photo = new Photo() };
        }
        else
        {
            MainSp.DataContext = Help.Db.Drivers.First(el => el.Id == _id);
            using (var ms = new MemoryStream((MainSp.DataContext as Driver).Photo.Photo1))
            {
                DriverPhoto.Source = new Bitmap(ms);
            }

            MainSp.IsEnabled = false;
            AddBtn.IsVisible = false;
        }
    }

    private void BackBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new DriverPage();
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        try
        {
            
        }
        catch
        {
            
        }
    }
}