using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Drivers.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}