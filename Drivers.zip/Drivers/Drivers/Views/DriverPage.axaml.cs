using System.Data.Common;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Drivers.Classes;
using Drivers.Data;
using Microsoft.EntityFrameworkCore;

namespace Drivers.Views;

public partial class DriverPage : UserControl
{
    public DriverPage()
    {
        InitializeComponent();
        LoadData();
    }

    void LoadData()
    {
        Help.Db.Photos.Load();
        Help.Db.Drivers.Load();
        DriversDg.ItemsSource = Help.Db.Drivers;
    }

    private void DeleteBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var selected = DriversDg.SelectedItem as Driver;
        if (selected != null)
        {
            Help.Db.Drivers.Remove(selected);
            Help.Db.SaveChanges();
            Help.MainCC.Content = new DriverPage();
        }
    }

    private void AddBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.MainCC.Content = new EditDrivers();
    }

    private void CardBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var selected = DriversDg.SelectedItem as Driver;
        if (selected != null)
        {
            Help.MainCC.Content = new EditDrivers(selected.Id);
        }
    }
}