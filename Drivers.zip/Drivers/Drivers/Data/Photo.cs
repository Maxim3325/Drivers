﻿using System;
using System.Collections.Generic;

namespace Drivers.Data;

public partial class Photo
{
    public int Id { get; set; }

    public byte[] Photo1 { get; set; } = null!;

    public virtual ICollection<Driver> Drivers { get; set; } = new List<Driver>();
}
